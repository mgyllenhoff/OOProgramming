// Exercise 13.18 Solution: Ex13_18.cpp
#include <iostream> 
using namespace std;

const size_t SIZE{80};

int main() {
   // prompt user to enter string and use getline() to store it
   cout << "Enter a sentence to test getline() and get():\n";
   char array[SIZE]; // array to hold getline() input 
   cin.getline(array, SIZE, '*');
   cout << array << '\n';

   char c;// holds next input value
   cin >> c; // read next character in input
   cout << "The next character in the input is: " << c << '\n';

   // use get() to obtain next value held in array
   char array2[SIZE]; // array to hold get() input
   cin.get(array2, SIZE, '*');
   cout << array2 << '\n';

   cin >> c; // read next character in input
   cout << "The next character in the input is: " << c << '\n';
} 

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
