// Exercise 20.9 Solution: Ex20_09.cpp
// BinarySearch test program.
#include <iostream>
#include <array>
#include <cstdlib> // prototypes for functions srand and rand
#include <ctime> // prototype for function time
#include <algorithm> // prototype for sort function
using namespace std;

const int SIZE{15};
void displayElements(const array<int, SIZE>& data);
void displaySubElements(const array<int, SIZE>& data, int low, int high);
int recursiveBinarySearch(const array<int, SIZE>& data, int searchElement, int low, int high);

int main() {
   srand(static_cast<unsigned int>(time(0))); // seed using current time

   array<int, SIZE> data;

   // insert random data
   for (int& item : data) {
      item = 10 + rand() % 90; // 10-99
   }

   sort(data.begin(), data.end()); // sort the data
   displayElements(data); // output array

   // get input from user
   cout << "\nPlease enter an integer value (-1 to quit): ";
   int searchInt; // search key
   cin >> searchInt; // read an int from user
   cout << endl;

   // repeatedly input an integer; -1 terminates the program
   while (searchInt != -1) {
      // use binary search to try to find integer
      int position{recursiveBinarySearch(data, searchInt, 0, SIZE - 1)};

      // return value of -1 indicates integer was not found
      if (position == -1) {
         cout << "The integer " << searchInt << " was not found.\n";
      }
      else {
         cout << "The integer " << searchInt 
            << " was found in position " << position << ".\n";
      }

      // get input from user
      cout << "\n\nPlease enter an integer value (-1 to quit): ";
      cin >> searchInt; // read an int from user
      cout << endl;
   } 
} 

// perform a binary search on the data
int recursiveBinarySearch(const array<int, SIZE>& data, int searchElement, int low, int high) {
   if (low > high) { // test base case; no element left to check
      return -1;
   }

   // print remaining elements of array to be searched
   displaySubElements(data, low, high);

   int middle{(low + high + 1) / 2}; // middle element

   // output spaces for alignment
   for (int i{0}; i < middle; ++i) {
      cout << "   ";
   }

   cout << " * " << endl; // indicate current middle

   int location{-1}; // variable to return; -1 if the value was not found

   // if the element is found at the middle
   if (searchElement == data[middle]) {
      location = middle; // location is the current middle
   }
   else if (searchElement < data[middle]) { // middle is too high
      // eliminate the higher half
      location = recursiveBinarySearch(data, searchElement, low, middle - 1); 
   }
   else { // middle element is too low
      // eliminate the lower half
      location = recursiveBinarySearch(data, searchElement, middle + 1, high);
   }

   return location; // return location of search key
} 

// display values in array
void displayElements(const array<int, SIZE>& data) {
   displaySubElements(data, 0, SIZE - 1);
} 

// display certain values in array
void displaySubElements(const array<int, SIZE>& data, int low, int high)  {
   for (int i{0}; i < low; ++i) { // output spaces for alignment
      cout << "   ";
   }

   for (int i{low}; i <= high; ++i) { // output elements left in array
      cout << data[i] << " ";
   }

   cout << endl;
} 

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
