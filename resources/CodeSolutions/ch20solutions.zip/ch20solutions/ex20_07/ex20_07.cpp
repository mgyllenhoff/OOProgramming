// Exercise 20.7 Solution: Ex20_07.cpp
// Test program that demonstrates bucket sort.
#include <array> 
#include <cstdlib> // prototypes for functions srand and rand
#include <ctime> // prototype for function time
#include <iostream> 
using namespace std;

void zeroBucket(array<array<int, 12>, 12>& bucket);
void sort(array<int, 12>& data);
void distributeElements(array<int, 12>& data, int digit, array<array<int, 12>, 12>& bucket);
void collectElements(array<int, 12> &data, array<array<int, 12>, 12>& bucket);
int numberOfDigits(const array<int, 12> &data);

int main() {
   srand(static_cast<unsigned int>(time(0))); // seed using current time

   array<int, 12> data;

   // fill array with random ints in range 10-99
   for (int& item : data) {
      item = 10 + rand() % 90; // 10-99
   }

   cout << "Vector elements in original order:\n";
   for (int item : data) {
      cout << item << " ";
   }
   cout << endl; 

   sort(data); // sort the array

   cout << "\nVector elements in sorted order:\n";
   for (int item : data) {
      cout << item << " ";
   }
   cout << endl; 
} 

// perform a bucket sort on array
void sort(array<int, 12>& data) {
   array<array<int, 12>, 12> bucket;
   zeroBucket(bucket);

   int totalDigits{numberOfDigits(data)};

   // put elements in buckets for sorting
   // once sorted, get elements from buckets
   for (int i{1}; i <= totalDigits; ++i) {
      distributeElements(data, i, bucket);
      collectElements(data, bucket);

      if (i != totalDigits) {
         zeroBucket(bucket); // set all bucket contents to zero
      }
   } 
} 

// distribute elements into buckets based on specified digit
void distributeElements(array<int, 12>& data, int digit, array<array<int, 12>, 12>& bucket)
{
   int divisor{10};

   for (int i{1}; i < digit; ++i) { // determine the divisor
      divisor *= 10; // used to get specific digit
   }

   for (size_t k{0}; k < data.size(); ++k) {
      // bucketNumber example for hundreds digit:
      // (1234 % 1000 - 1234 % 100) / 100 --> 2
      int bucketNumber{(data[k] % divisor - data[k] % (divisor / 10)) / (divisor / 10)};

      // retrieve value in bucket[bucketNumber][0] to determine
      // which element of the row to store a[i] in.
      int elementNumber{++bucket[bucketNumber][0]};
      bucket[bucketNumber][elementNumber] = data[k];
   } 
} 

// return elements to original array
void collectElements(array<int, 12>& data, array<array<int, 12>, 12>& bucket)
{
   int subscript{0};

   // retrieve elements from bucket array
   for (int i{0}; i < 10; ++i) {
      for (int j{1}; j <= bucket[i][0]; ++j) {
         data[subscript++] = bucket[i][j];
      }
   } 
} 

// determine the number of digits in the largest number
int numberOfDigits(const array<int, 12>& data) {
   int largest{data[0]};
   int digits{0};

   // find largest array element
   for (size_t i{1}; i < data.size(); ++i) {
      if (data[i] > largest) {
         largest = data[i]; 
      }
   } 

   // find number of digits of largest element
   while (largest != 0) {
      ++digits;
      largest /= 10;
   } 

   return digits;
} 

// set all buckets to zero
void zeroBucket(array<array<int, 12>, 12>& bucket) {
   // set all array elements to zero
   for (auto &row : bucket) {
      for (auto &column : row) {
         column = 0;
      }
   }
} 


/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
