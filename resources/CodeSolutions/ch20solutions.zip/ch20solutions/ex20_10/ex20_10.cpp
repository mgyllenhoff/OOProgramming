// Exercise 20.10 Solution: Ex20_10.cpp
// Quick sort of a array.
#include <iostream> 
#include <iomanip> 
#include <cstdlib>
#include <ctime>
#include <array>
using namespace std;

const int SIZE = 10;

// function prototypes
void quickSortHelper(array < int, SIZE > &, int, int);
int partition(array < int, SIZE > &, int, int);
void swap(int * const, int * const);

int main() {
   srand(static_cast<unsigned int>(time(0)));
   const int MAX_NUMBER{100};
   array<int, SIZE> arrayToBeSorted;

   // randomly generate content 
   for (int& item : arrayToBeSorted) {
      item = rand() % MAX_NUMBER;
   }

   cout << "Initial array values are:\n";
   
   // print out values of the array
   for (int item : arrayToBeSorted) {
       cout << setw(4) << item;
   }
   cout << "\n\n";

   // if there is only one element
   if (SIZE == 1) {
      cout << "Array is sorted: " << arrayToBeSorted[0] << '\n';
   }
   else 
   {
      quickSortHelper(arrayToBeSorted, 0, SIZE - 1);
      cout << "The sorted array values are:\n";

      for (int item : arrayToBeSorted) {
         cout << setw(4) << item;
      }

      cout << endl;
   } 
} 

// recursive function to sort array
void quickSortHelper(array<int, SIZE>& data, int first, int last) {
   if (first >= last) {
      return;
   }

   int currentLocation = partition(data, first, last); // place an element
   quickSortHelper(data, first, currentLocation - 1); // sort left side
   quickSortHelper(data, currentLocation + 1, last); // sort right side
} 

// partition the array into multiple sections
int partition(array<int, SIZE>& data, int left, int right) {
   int position{left};

   // loop through the portion of the array
   while (true) {
      while (data[position] <= data[right] && position != right) {
         --right;
      }

      if (position == right) {
         return position;
      }

      if (data[position] > data[right]) {
         swap(&data[position], &data[right]);
         position = right;
      } 

      while (data[left] <= data[position] && left != position) {
         ++left;
      }

      if (position == left) {
         return position;
      }

      if (data[left] > data[position]) {
         swap(&data[position], &data[left]);
         position = left;
      } 
   } 
} 

// swap locations
void swap(int * const ptr1, int * const ptr2)
{
   int temp;

   temp = *ptr1;
   *ptr1 = *ptr2;
   *ptr2 = temp;
} 


/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
