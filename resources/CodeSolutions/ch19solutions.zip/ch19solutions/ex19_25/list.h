// Fig. 19.5: List.h
// List class-template definition.
#ifndef LIST_H
#define LIST_H

#include <iostream>
#include "ListNode.h" // ListNode class definition

template<typename NODETYPE>
class List {
public:
   // default constructor
   List() {
      firstPtr = lastPtr = nullptr;
   }

   // copy constructor
   List(const List<NODETYPE>& copy) {
      firstPtr = lastPtr = nullptr; // initialize pointers

      ListNode<NODETYPE>* currentPtr{copy.firstPtr};

      // insert into the list
      while (currentPtr != 0) {
         insertAtBack(currentPtr->data);
         currentPtr = currentPtr->nextPtr;
      }
   }

   // destructor
   ~List() {
      if (!isEmpty()) { // List is not empty
         std::cout << "Destroying nodes ...\n";

         ListNode<NODETYPE>* currentPtr{firstPtr};
         ListNode<NODETYPE>* tempPtr{nullptr};

         while (currentPtr != nullptr) { // delete remaining nodes
            tempPtr = currentPtr;
            std::cout << tempPtr->data << '\n';
            currentPtr = currentPtr->nextPtr;  
            delete tempPtr;
         } 
      } 

      std::cout << "All nodes destroyed\n\n";
   } 

   // insert node at front of list
   void insertAtFront(const NODETYPE& value) {
      ListNode<NODETYPE>* newPtr{getNewNode(value)}; // new node

      if (isEmpty()) { // List is empty
         firstPtr = lastPtr = newPtr; // new list has only one node
      } 
      else { // List is not empty
         newPtr->nextPtr = firstPtr; // point new node to old 1st node
         firstPtr = newPtr; // aim firstPtr at new node
      } 
   } 

   // insert node at back of list
   void insertAtBack(const NODETYPE& value) {
      ListNode<NODETYPE>* newPtr{getNewNode(value)}; // new node

      if (isEmpty()) { // List is empty
         firstPtr = lastPtr = newPtr; // new list has only one node
      } 
      else { // List is not empty
         lastPtr->nextPtr = newPtr; // update previous last node
         lastPtr = newPtr; // new last node
      } 
   } 

   // delete node from front of list
   bool removeFromFront(NODETYPE& value) {
      if (isEmpty()) { // List is empty
         return false; // delete unsuccessful
      } 
      else {
         ListNode<NODETYPE>* tempPtr{firstPtr}; // hold item to delete

         if (firstPtr == lastPtr) {
            firstPtr = lastPtr = nullptr; // no nodes remain after removal
         } 
         else {
            firstPtr = firstPtr->nextPtr; // point to previous 2nd node
         } 

         value = tempPtr->data; // return data being removed
         delete tempPtr; // reclaim previous front node
         return true; // delete successful
      } 
   } 

   // delete node from back of list

   bool removeFromBack(NODETYPE& value) {
      if (isEmpty()) { // List is empty
         return false; // delete unsuccessful
      } 
      else {
         ListNode<NODETYPE>* tempPtr{lastPtr}; // hold item to delete

         if (firstPtr == lastPtr) { // List has one element
            firstPtr = lastPtr = nullptr; // no nodes remain after removal
         }
         else {
            ListNode<NODETYPE>* currentPtr{firstPtr};

            // locate second-to-last element            
            while (currentPtr->nextPtr != lastPtr) {   
               currentPtr = currentPtr->nextPtr; // move to next node
            }

            lastPtr = currentPtr; // remove last node
            currentPtr->nextPtr = nullptr; // this is now the last node
         } 

         value = tempPtr->data; // return value from old last node
         delete tempPtr; // reclaim former last node
         return true; // delete successful
      } 
   } 

   // is List empty?

   bool isEmpty() const {
      return firstPtr == nullptr; 
   } 

   // display contents of List
   void print() const {
      if (isEmpty()) { // List is empty
         std::cout << "The list is empty\n\n";
         return;
      } 

      ListNode<NODETYPE>* currentPtr{firstPtr};

      std::cout << "The list is: ";

      while (currentPtr != nullptr) { // get element data
         std::cout << currentPtr->data << ' ';
         currentPtr = currentPtr->nextPtr;
      } 

      std::cout << "\n\n";
   } 

   // insert node anywhere in list
   bool insertByLocation(const NODETYPE& value, int location) {
      int count{1};

      // if list is empty and index is not 0, then index is not valid
      if (isEmpty() && (location != 0)) {
         return false;
      }

      if (location < 0) { // negative indices are invalid
         return false;
      }
      else if (location == 0) { // if index 0, simply insert at front
         insertAtFront(value);
         return true; // successful insertion
      }

      // pointers used to keep track of current node,
      // previous node and new node
      ListNode<NODETYPE>* currentPtr{firstPtr->nextPtr};
      ListNode<NODETYPE>* previousPtr{firstPtr};
      ListNode<NODETYPE>* newPtr{getNewNode(value)};

      // loop until we reach proper location
      while (count < location) {
         if (currentPtr == lastPtr) { // if end of list found first
            if (location == count + 1) {
               // if user specified index one after end of list,
               // add node at back of list
               insertAtBack(value);
               return true; // successful insertion
            }

            return false; // index too large, invalid input
         }
         else {
            // continue to next position in list
            previousPtr = currentPtr;
            currentPtr = currentPtr->nextPtr;
            count++;
         }
      }

      // we have reached specified location, insert new node
      previousPtr->nextPtr = newPtr;
      newPtr->nextPtr = currentPtr;
      return true; // successful insertion
   }

   // delete specified value
   bool deleteNodeByValue(const NODETYPE& val, NODETYPE& deletedVal) {
      if (isEmpty()) {
         return false; // delete unsuccessful
      }
      if (firstPtr->getData() == val) { // value at beginning of list
         return removeFromFront(deletedVal); // remove from the front
      }
      else { // search through list for value specified
         // pointers used to keep track of current and previous nodes
         ListNode<NODETYPE>* currentPtr{firstPtr};
         ListNode<NODETYPE>* previousPtr;

         // loop until end of list reached
         do {
            // move to next node
            previousPtr = currentPtr;
            currentPtr = currentPtr->getNextPtr();

            // if value found
            if (currentPtr->getData() == val) {
               // store data of node to be deleted
               ListNode<NODETYPE>* tempPtr = currentPtr;
               deletedVal = currentPtr->getData();

               // have previous node point to next node
               previousPtr->setNextPtr(currentPtr->getNextPtr());

               delete tempPtr; // delete node
               return true; // delete successful
            }
         } while (currentPtr != lastPtr);

         // if we are here, reached end of list and did not find value
         return false; // delete unsuccessful
      }
   }

   bool deleteNodeByLocation(NODETYPE& deletedValue, int location) {
      int count{1}; // counter used to move through list

      if (isEmpty()) {
          return false; // no nodes to delete
      }

      if (location < 0) { // invalid index
         return false;
      }
      else if (location == 0) { // index 0, remove from front of list
         return removeFromFront(deletedValue);
      }

      // keep track of current and previous pointers
      ListNode<NODETYPE>* currentPtr{firstPtr->nextPtr};
      ListNode<NODETYPE>* previousPtr{firstPtr};

      // move through list until proper location reached
      while (count < location) {
         if ((currentPtr == lastPtr)) { // if end of list reached first
            return false; // invalid index entered
         }
         else {
            // move to next node in list
            previousPtr = currentPtr;
            currentPtr = currentPtr->nextPtr;
            count++;
         }
      }

      // we have reached specified location, remove node
      ListNode<NODETYPE>* tempPtr{currentPtr};
      deletedValue = currentPtr->getData();

      // have previous node point to next node
      previousPtr->setNextPtr(currentPtr->getNextPtr());

      delete tempPtr; // delete node
      return true; // delete successful
   }

protected:
   ListNode<NODETYPE>* firstPtr{nullptr}; // pointer to first node
   ListNode<NODETYPE>* lastPtr{nullptr}; // pointer to last node  

   // utility function to allocate new node
   ListNode<NODETYPE>* getNewNode(const NODETYPE& value) {
      return new ListNode<NODETYPE>{value};
   } 
}; 

#endif

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
