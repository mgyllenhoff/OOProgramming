// Exercise 20.12 Solution: StackNode.h
// Definition of class template StackNode.
#ifndef STACKNODE_H
#define STACKNODE_H

template<typename T> class Stack; // forward declaration

template<typename T>
class StackNode {
   friend class Stack<T>;
public:
   // constructor
   StackNode(const T& d = 0, StackNode<T>* ptr = nullptr) {
      data = d;
      nextPtr = ptr;
   } 

   // get data
   T getData() const { 
      return data; 
   } 


   // set point to next stack node
   void setNextPtr(StackNode* nPtr) { 
      nextPtr = nPtr; 
   } 
   
   // get point to next stack node
   StackNode* getNextPtr() const { 
      return nextPtr; 
   } 

private:
   T data;
   StackNode* nextPtr;
}; 

#endif

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
