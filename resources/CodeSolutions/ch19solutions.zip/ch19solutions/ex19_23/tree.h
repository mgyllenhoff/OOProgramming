// Fig. 19.22: Tree.h
// Tree class-template definition.
#ifndef TREE_H
#define TREE_H

#include <iostream>
#include "TreeNode.h"
#include "queue.h"

// Tree class-template definition
template<typename NODETYPE> class Tree {
public:
   // insert node in Tree
   void insertNode(const NODETYPE& value) {
      insertNodeHelper(&rootPtr, value); 
   } 

   // begin preorder traversal of Tree
   void preOrderTraversal() const {
      preOrderHelper(rootPtr); 
   } 

   // begin inorder traversal of Tree
   void inOrderTraversal() const {
      inOrderHelper(rootPtr); 
   } 

   // begin postorder traversal of Tree
   void postOrderTraversal() const {
      postOrderHelper(rootPtr); 
   } 

   // get the depth of the tree
   int getDepth() const {
      int totalDepth{0};
      int currentDepth{0};

      determineDepth(rootPtr, &totalDepth, &currentDepth);
      return totalDepth;
   }

   // begin binary search
   TreeNode<NODETYPE>* binaryTreeSearch(int val) const {
      return binarySearchHelper(rootPtr, val);
   }


   // perform level-order traversal
   void levelOrder() const {
      Queue<TreeNode<NODETYPE>*> queue;
      TreeNode<NODETYPE>* nodePtr;

      if (rootPtr != nullptr) {
         queue.enqueue(rootPtr);
      }

      while (!queue.isEmpty()) {
         nodePtr = queue.dequeue();
         cout << nodePtr->data << ' ';

         if (nodePtr->leftPtr != nullptr) {
            queue.enqueue(nodePtr->leftPtr);
         }

         if (nodePtr->rightPtr != nullptr) {
            queue.enqueue(nodePtr->rightPtr);
         }
      }
   }

private:
   TreeNode<NODETYPE>* rootPtr{nullptr};

   // utility function called by insertNode; receives a pointer
   // to a pointer so that the function can modify pointer's value
   void insertNodeHelper(
      TreeNode<NODETYPE>** ptr, const NODETYPE& value) {
      // subtree is empty; create new TreeNode containing value
      if (*ptr == nullptr) {
         *ptr = new TreeNode<NODETYPE>(value);
      }
      else { // subtree is not empty
             // data to insert is less than data in current node
         if (value <= (*ptr)->data) {
            insertNodeHelper(&((*ptr)->leftPtr), value);
         }
         else {
            insertNodeHelper(&((*ptr)->rightPtr), value);
         } 
      } 
   } 

   // utility function to perform preorder traversal of Tree
   void preOrderHelper(TreeNode<NODETYPE>* ptr) const {
      if (ptr != nullptr) {
         cout << ptr->data << ' '; // process node               
         preOrderHelper(ptr->leftPtr); // traverse left subtree  
         preOrderHelper(ptr->rightPtr); // traverse right subtree
      } 
   } 

   // utility function to perform inorder traversal of Tree
   void inOrderHelper(TreeNode<NODETYPE>* ptr) const {
      if (ptr != nullptr) {
         inOrderHelper(ptr->leftPtr); // traverse left subtree  
         cout << ptr->data << ' '; // process node              
         inOrderHelper(ptr->rightPtr); // traverse right subtree
      } 
   } 

   // utility function to perform postorder traversal of Tree
   void postOrderHelper(TreeNode<NODETYPE>* ptr) const {
      if (ptr != nullptr) { 
         postOrderHelper(ptr->leftPtr); // traverse left subtree  
         postOrderHelper(ptr->rightPtr); // traverse right subtree
         cout << ptr->data << ' '; // process node                
      } 
   } 

   // calculate the depth of the tree
   void determineDepth(TreeNode<NODETYPE>* ptr, int* totPtr, int* currPtr) const {
      if (ptr != 0) { // until ptr points to 0
         (*currPtr)++;

         if (*currPtr > *totPtr) {
            *totPtr = *currPtr;
         }

         determineDepth(ptr->getLeftPtr(), totPtr, currPtr);
         determineDepth(ptr->getRightPtr(), totPtr, currPtr);
         (*currPtr)--;
      }
   }

   // do a binary search on the Tree
   TreeNode<NODETYPE>* binarySearchHelper(TreeNode<NODETYPE>* ptr, int value) const {
      // if value is not found
      if (ptr == nullptr)
         return nullptr;

      cout << "Comparing " << value << " to " << ptr->getData();

      if (value == ptr->getData()) { // match
         cout << "; search complete\n";
         return ptr;
      }
      else if (value < ptr->getData()) { // value is less than current data
         cout << "; smaller, walk left\n";
         return binarySearchHelper(ptr->getLeftPtr(), value);
      }
      else { // search value is greater than current data
         cout << "; larger, walk right\n";
         return binarySearchHelper(ptr->getRightPtr(), value);
      }
   }

}; 

#endif


/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
