// Exercise 21.23 Solution: Ex21_23.cpp
// Program prints a pyramid from a string.
#include <iostream> 
#include <string>
using namespace std;

int main() {
   string alpha{"abcdefghijklmnopqrstuvwxyz{"};
   string::const_iterator x{alpha.begin()};
   const int SIZE{14};

   for (int p{1}; p <= SIZE; ++p, ++x) {
      // output spaces
      //cout << string(SIZE - P, ' ');

      for (int k{13}; k >= p; --k) {
         cout << ' ';
      }

      cout << string(x, x + p);
      string::const_reverse_iterator rb{x + p - 1};
      string::const_reverse_iterator re{x};
      cout << string(rb, re);
      cout << '\n';
   } 
} 

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
