// Exercise 10.10 Solution: ex10_10.cpp
// RationalNumber test program.
#include <iostream> 
#include "RationalNumber.h"
using namespace std;

int main() {
   RationalNumber c{7, 3}; 
   RationalNumber d{3, 9};

   RationalNumber x = c + d; // test overloaded operators + and =
   cout << c.toString() << " + " << d.toString() << " = " << x.toString() << "\n";

   x = c - d; // test overloaded operators - and =
   cout << c.toString() << " - " << d.toString() << " = " << x.toString() << "\n";

   x = c * d; // test overloaded operators * and =
   cout << c.toString() << " * " << d.toString() << " = " << x.toString() << "\n";

   x = c / d; // test overloaded operators / and =
   cout << c.toString() << " / " << d.toString() << " = " << x.toString() << "\n";

   cout << boolalpha;
   cout << c.toString() << " > " << d.toString() << " is " << (c > d) << "\n";
   cout << c.toString() << " < " << d.toString() << " is " << (c < d) << "\n";
   cout << c.toString() << " >= " << d.toString() << " is " << (c >= d) << "\n";
   cout << c.toString() << " <= " << d.toString() << " is " << (c <= d) << "\n";
   cout << c.toString() << " == " << d.toString() << " is " << (c == d) << "\n";
   cout << c.toString() << " != " << d.toString() << " is " << (c != d) << "\n";
} 



/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
