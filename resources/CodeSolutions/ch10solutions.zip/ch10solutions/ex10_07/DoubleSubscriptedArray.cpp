// Exercise 10.7 Solution: DoubleSubscriptedArray.cpp
// DoubleSubscriptedArray class member- and friend-function definitions.
#include <iostream>
#include <iomanip>
#include <stdexcept>
#include <cstdlib> // exit function prototype
#include "DoubleSubscriptedArray.h" // DoubleSubscriptedArray definition
using namespace std;

// default constructor for class DoubleSubscriptedArray
DoubleSubscriptedArray::DoubleSubscriptedArray(int rowSizeEntered, int columnSizeEntered)
   : ptr(nullptr) {
   // validate row and column size
   if (rowSizeEntered > 0) {
       rowSize = rowSizeEntered;
   }
   else {
      throw invalid_argument("Row size must be > 0");
   }
 
   if (columnSizeEntered > 0) {
       columnSize = columnSizeEntered;
   }
   else {
      throw invalid_argument("Column size must be > 0");
   }

   ptr = new int[rowSize * columnSize]; // create space for array

   for (size_t loop{0}; loop < rowSize * columnSize; ++loop) {
      ptr[loop] = 0; // set pointer-based array element
   }
} 

// copy constructor for class DoubleSubscriptedArray;
// must receive a reference to prevent infinite recursion
DoubleSubscriptedArray::DoubleSubscriptedArray(const DoubleSubscriptedArray& arrayToCopy)
   : rowSize(arrayToCopy.rowSize), columnSize(arrayToCopy.columnSize)
{
   ptr = new int[rowSize * columnSize]; // create space for array

   for (size_t loop{0}; loop < rowSize * columnSize; ++loop) {
      ptr[loop] = arrayToCopy.ptr[loop]; // copy into object
   }
} 

// destructor for class DoubleSubscriptedArray
DoubleSubscriptedArray::~DoubleSubscriptedArray() {
   delete [] ptr; // release pointer-based array space
} 

// return number of rows of DoubleSubscriptedArray
size_t DoubleSubscriptedArray::getRowSize() const {
   return rowSize; // number of rows in DoubleSubscriptedArray
} 

// return number of columns of DoubleSubscriptedArray
size_t DoubleSubscriptedArray::getColumnSize() const {
   return columnSize; // number of columns in DoubleSubscriptedArray
} 

// overloaded assignment operator;
// const return avoids: (a1 = a2) = a3
const DoubleSubscriptedArray& DoubleSubscriptedArray::operator=(const DoubleSubscriptedArray& right)
{
   if (&right != this) { // avoid self-assignment 
      // for arrays of different sizes, deallocate original
      // left-side array, then allocate new left-side array
      if (rowSize * columnSize != right.rowSize * right.columnSize) {
         delete [] ptr; // release space
         rowSize = right.rowSize; // resize this object
         columnSize = right.columnSize;
         ptr = new int[rowSize * columnSize]; // create space for copy
      } 

      for (size_t loop = 0; loop < rowSize * columnSize; ++loop) {
         ptr[loop] = right.ptr[loop]; // copy into object
      }
   } 

   return *this; // enables x = y = z, for example
} 

// determine if two DoubleSubscriptedArrays are equal and
// return true, otherwise return false
bool DoubleSubscriptedArray::operator==(const DoubleSubscriptedArray& right) const {
   if (rowSize * columnSize != right.rowSize * right.columnSize) {
      return false; // arrays of different number of elements
   }

   for (size_t loop{0}; loop < rowSize * columnSize; ++loop) {
      if (ptr[loop] != right.ptr[loop]) {
         return false; // DoubleSubscriptedArray contents are not equal
      }
   }

   return true; // DoubleSubscriptedArrays are equal
} 

// overloaded subscript operator for non-const DoubleSubscriptedArrays;
// reference return creates a modifiable lvalue
int &DoubleSubscriptedArray::operator()(size_t rowSubscript, size_t columnSubscript) {
   // check for subscript out-of-range error
   if ((rowSubscript < 0 || rowSubscript >= rowSize) ||
      (columnSubscript < 0 || columnSubscript >= columnSize)) {
      throw invalid_argument("One or both subscripts out of range");
   }

   // reference return
   return ptr[(rowSubscript * columnSize) + columnSubscript];
} 

// overloaded subscript operator for const DoubleSubscriptedArrays
// const reference return creates an rvalue
int DoubleSubscriptedArray::operator()(size_t rowSubscript, size_t columnSubscript) const {
   // check for subscript out-of-range error
   if ((rowSubscript < 0 || rowSubscript >= rowSize) ||
      (columnSubscript < 0 || columnSubscript >= columnSize)) {
      throw invalid_argument("One or both subscripts out of range");
   }

   // returns copy of this element
   return ptr[(rowSubscript * columnSize) + columnSubscript];
} 

// overloaded input operator for class DoubleSubscriptedArray;
// inputs values for entire DoubleSubscriptedArray
istream &operator>>(istream& input, DoubleSubscriptedArray& a) {
   for (size_t loop{0}; loop < a.rowSize * a.columnSize; ++loop) {
      input >> a.ptr[loop];
   }

   return input; // enables cin >> x >> y;
} 

// overloaded output operator for class DoubleSubscriptedArray
ostream& operator<<(ostream& output, const DoubleSubscriptedArray& a)
{
   for (size_t loop{0}; loop < a.rowSize; ++loop) {
      for (size_t loop2 = 0; loop2 < a.columnSize; ++loop2) {
         output << a.ptr[(loop * a.columnSize) + loop2] << ' ';
      }

      output << endl;
   } 

   return output; // enables cout << x << y;
} 

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
