// Exercise 16.11: Ex16_11.cpp
// Reading data from a file
#include <iostream>
#include <algorithm>
#include <iterator>
#include <string>
#include <list>

using namespace std;

int main() {
   list<string> strings1;
   strings1.push_back("blue");
   strings1.push_back("red");
   strings1.push_back("yellow");

   list<string> strings2;
   strings2.push_back("cyan");
   strings2.push_back("magenta");
   strings2.push_back("orange");

   list<string> results;

   merge(strings1.begin(), strings1.end(), strings2.begin(), strings2.end(), back_inserter(results));

   ostream_iterator<string> output{cout, " "};
   cout << "The merged list of strings contains: ";
   copy(results.begin(), results.end(), output);
   cout << endl;
}


/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
