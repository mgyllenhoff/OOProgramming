// Exercise 16.13: Ex16_13.cpp
// Reading data from a file
#include <iostream>
#include <algorithm>
#include <iterator>
#include <string>
#include <cctype>

using namespace std;

bool palindromeTester(const string& string1) {
   string string2(string1);
   reverse(string2.begin(), string2.end());

   return string1 == string2;
}

int main() {
   cout << "Enter a string to test whether it's a palindrome" << endl;
   
   string s;
   getline(cin, s);

   // convert to lowercase
   for (char &c : s) {
      c = tolower(c);
   }

   string s2;

   // remove punctuation
   copy_if(s.begin(), s.end(), back_inserter(s2), [](char c){ return !ispunct(c); });

   if (palindromeTester(s2)) {
      cout << s << " without punctuation is a palindrome" << endl;
   }
   else {
      cout << s << " without punctuation is not a palindrome" << endl;
   }
}


/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
