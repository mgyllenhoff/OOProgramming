// Exercise 22.09 Solution: ex22_09.cpp
#include <iostream> 
#include <iomanip> 
using namespace std;

// prototypes
void unpackCharacters(char[], unsigned);
void displayBits(unsigned);

int main() {
   char characters[4];
   unsigned packed{1633903975}; // a, c, e, g
   
   cout << "The packed character representation is:\n";
   displayBits(packed);

   // demonstrate unpacking of characters  
   unpackCharacters(characters, packed);
   cout << "\nThe unpacked characters are: ";
   for (size_t i{0}; i < 4; ++i) {
      cout << characters[i] << " ";
   }
   cout << endl;

   cout << "\nThe unpacked characters in bits are:" << endl;
   for (size_t i{0}; i < 4; ++i) {
      displayBits(characters[i]);
   }
} 

// take apart the characters
void unpackCharacters(char characters[], unsigned pack) {
   unsigned mask1{4278190080};
   unsigned mask2{16711680};
   unsigned mask3{65280};
   unsigned mask4{255};
   
   characters[0] = static_cast<char>((pack & mask1) >> 24);
   characters[1] = static_cast<char>((pack & mask2) >> 16);
   characters[2] = static_cast<char>((pack & mask3) >> 8);
   characters[3] = static_cast<char>(pack & mask4);
} 

// display the bits of value
void displayBits(unsigned value) {
   const int SHIFT{8 * sizeof(unsigned) - 1};
   const unsigned MASK{static_cast<unsigned>(1 << SHIFT)};

   cout << setw(7) << value << " = ";
	
   for (unsigned c{1}; c <= SHIFT + 1; ++c) {
      cout << (value & MASK ? '1' : '0');
      value <<= 1;
	
      if (c % 8 == 0) {
         cout << ' ';
      }
   } 
	
   cout << endl;
} 



/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
