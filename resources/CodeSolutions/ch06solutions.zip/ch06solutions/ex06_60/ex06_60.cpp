// Exercise 6.60 Solution: Ex06_60.cpp
// Help user practice multiplication according to grade level;
// check user's progress every 10 responses.
#include <iostream> 
#include <cmath>
#include <cstdlib>
#include <ctime>
using namespace std;

int generateProblem(int); // function prototype
void correctMessage(); // function prototype
void incorrectMessage(); // function prototype
bool checkDone(unsigned int, unsigned int); // function prototype

int main() {
   srand(static_cast<unsigned int>(time(0)));
   
   int response{0}; // user response for product
   unsigned int correct{0}; // total number of correct responses
   unsigned int incorrect{0}; // total number of incorrect responses
   unsigned int level{0}; // difficulty level

   cout << "Enter difficulty level: ";
   cin >> level;

   // loop until sentinel value read from user
   while (response != -1) {
      int answer{generateProblem(level)}; // get product
      cin >> response; // read user's guess

      // loop until sentinel value or correct response
      while (response != -1 && response != answer) {
         ++incorrect; // update total number of incorrect responses

         if (checkDone(correct, incorrect)) { // check progress
            // done 10 responses; reset for next person
            correct = 0;
            incorrect = 0;
            break;
         } 

         incorrectMessage();
         cin >> response;
      } 

      // correct response
      if (response == answer) {
         ++correct; // update total number of correct responses

         if (checkDone(correct, incorrect)) { // check progress
            // done 10 responses; reset for next person
            correct = 0;
            incorrect = 0;
            continue;
         } 

         correctMessage();
      } 
   } 

   cout << "That's all for now. Bye." << endl;
} 

// generates new product and displays prompt
int generateProblem(int level) {
   // maximum value for a particular level
   int max{static_cast<int>(pow(10.0, level))};
   int x{rand() % max}; // generate random number
   int y{rand() % max}; // generate random number

   cout << "How much is " << x << " times " << y << " (-1 to End)\n? ";

   return x * y; // return product
} 

// correctMessage randomly chooses response to correct answer
void correctMessage() {
   // generate random number between 0 and 3
   switch (rand() % 4) {
      case 0:
         cout << "Very good!";
         break;
      case 1:
         cout << "Excellent!";
         break;
      case 2:
         cout << "Nice work!";
         break;
      case 3:
         cout << "Keep up the good work!";
         break;
   } 

   cout << endl << endl;
} 

// incorrectMessage randomly chooses response to incorrect answer
void incorrectMessage() {
   // generate random number between 0 and 3
   switch (rand() % 4) {
      case 0:
         cout << "No. Please try again.";
         break;
      case 1:
         cout << "Wrong. Try once more.";
         break;
      case 2:
         cout << "Don't give up!";
         break;
      case 3:
         cout << "No. Keep trying.";
         break;
   } 

   cout << endl << "? ";
} 

// based on number of correct and incorrect, print
// result and return true if student's turn is over
bool checkDone(unsigned int right, unsigned int wrong) {
   // if we've reached a total of 10 responses
   if (right + wrong == 10) {
      // check whether student got 75% correct or not
      if (static_cast<double>(right) / (right + wrong) < .75) {
         cout << "Please ask your teacher for extra help.\n\n";
      }
      else {
         cout << "Congratulations, you are ready to go "
            << "to the next level!\n\n";
      }

      return true;
   } 

   return false;
} 

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
