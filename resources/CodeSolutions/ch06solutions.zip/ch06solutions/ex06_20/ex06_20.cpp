// Exercise 6.20 Solution: Ex06_20.cpp
// Determines whether, for a pair of integers,
// the second is a multiple of the first.
#include <iostream>
using namespace std;

bool isMultiple(unsigned int, unsigned int); // function prototype

int main() {
   unsigned int x{0}; // first integer
   unsigned int y{0}; // second integer

   // loop 3 times
   for (unsigned int i{1}; i <= 3; ++i) {
      cout << "Enter two integers: ";
      cin >> x >> y;
   
      // determine if second is multiple of first
      if (isMultiple(x, y)) {
         cout << y << " is a multiple of " << x << "\n\n";
      }
      else {
         cout << y << " is not a multiple of " << x << "\n\n";
      }
   }

   cout << endl;
} 

// multiple determines if b is multiple of a
bool isMultiple(unsigned int a, unsigned int b) {
   return !(b % a);
} 

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
