// Exercise 6.25 Solution: Ex06_25.cpp
// Calculate amount of time in seconds between two times.
#include <iostream>
#include <cmath>
using namespace std;

unsigned int seconds(unsigned int, unsigned int, unsigned int); // function prototype

int main() {
   unsigned int hours{0}; // current time's hours
   unsigned int minutes{0}; // current time's minutes
   unsigned int secs{0}; // current time's seconds

   cout << "Enter the first time as three integers: ";
   cin >> hours >> minutes >> secs;
   double first = seconds(hours, minutes, secs); // calculate first time

   cout << "Enter the second time as three integers: ";
   cin >> hours >> minutes >> secs;
   double second = seconds(hours, minutes, secs); // calculate second time
   double difference = fabs(first - second); // calculate difference

   // display difference
   cout << "The difference between the times is "
      << difference << " seconds" << endl;
} 

// seconds returns number of seconds since clock "struck 12"
// given input time as hours h, minutes m, seconds s
unsigned int seconds(unsigned int h, unsigned int m, unsigned int s) {
   return 3600 * (h >= 12 ? h - 12 : h) + 60 * m + s;
} 

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
