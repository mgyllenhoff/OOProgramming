// Exercise 15.25: Ex15_25.cpp
// Using a bitset to demonstrate the Sieve of Eratosthenes.
// Show all prime factors of any non-prime numbers.
#include <iostream>
#include <iomanip>
#include <iterator>
#include <cmath> 
#include <bitset> // bitset class definition
#include <set>
using namespace std;

bool getPrimeFactors(int value, multiset<int>& factors);

int main() {
   const size_t SIZE{1024};
   bitset<SIZE> sieve; // create bitset of 1024 bits
   sieve.flip(); // flip all bits in bitset sieve     
   sieve.reset(0); // reset first bit (number 0)    
   sieve.reset(1); // reset second bit (number 1)   

   // perform Sieve of Eratosthenes
   size_t finalBit{static_cast<size_t>(sqrt(static_cast<double>(sieve.size())) + 1)};

   // determine all prime numbers from 2 to 1024
   for (size_t i{2}; i < finalBit; ++i) {
      if (sieve.test(i)) { // bit i is on
         for (int j = 2 * i; j < SIZE; j += i) {
            sieve.reset(j); // set bit j off
         }
      } 
   } 

   cout << "The prime numbers in the range 2 to 1023 are:\n";

   // display prime numbers in range 2-1023
   for (size_t k{2}, counter = 1; k < SIZE; ++k) {
      if (sieve.test(k)) { // bit k is on
         cout << setw(5) << k;

         if (counter++ % 12 == 0) { // counter is a multiple of 12
            cout << '\n';
         }
      }      
   } 
   
   cout << endl;

   // get value from user to determine whether value is prime
   cout << "\nEnter a value from 2 to 1023 (-1 to end): ";
   int value;
   cin >> value;

   // determine whether user input is prime
   while (value != -1) {
      if (sieve[value]) { // prime number
         cout << value << " is a prime number\n";
      }
      else { // not a prime number
         cout << value << " is not a prime number\n";
         
         multiset<int> factors;
         ostream_iterator<int> output(cout, " ");

         getPrimeFactors(value, factors);
         copy(factors.cbegin(), factors.cend(), output);
      }

      cout << "\nEnter a value from 2 to 1023 (-1 to end): ";
      cin >> value;
   } 
} 

// show a number's prime factors
bool getPrimeFactors(int value, multiset<int>& factors) {
   if (value == 0 || value == 1) {
      return false;
   }

   // loop through numbers that are less than or equal to number/2
   for (int factor{2}; factor <= value / 2; factor++) {
      // has factor
      if (value % factor == 0) {
         factors.insert(factor); // save the factor

         // just look at what's left over for more factors
         if (!getPrimeFactors((value / factor), factors)) {
            factors.insert(value / factor);
         }

         return true;
      } 
   } 

   return false;
} 


/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
