// Exercise 7.27 Solution: Ex07_27.cpp
#include <iostream> 
#include <iomanip> 
#include <array>
using namespace std;

int main() {
   const size_t SIZE{1000};
   array<bool, SIZE> sieve;
   unsigned int count{0};

   // set all sieve elements to true
   for (auto& element : sieve) {
      element = true;
   }

   // test for multiples of current subscript
   for (size_t i{1}; i < SIZE; ++i) {
      if (sieve[i] == true && i != 1) {
         for (size_t j{i}; j < SIZE; ++j) {
            if (j % i == 0 && j != i) {
               sieve[j] = false;
            }
         } 
      } 
   } 

   // display prime numbers 
   for (size_t q{2}; q < SIZE; ++q) {
      if (sieve[q] == true) {
         cout << setw(3) << q << " is a prime number.\n";
         ++count;
      } 
   } 

   cout << "A total of " << count << " prime numbers were found." << endl;
} 

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
