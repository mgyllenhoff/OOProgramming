// Exercise 7.35 Solution: ex07_35.cpp
// Analyze polling data on various issues.
#include <iomanip>
#include <iostream>
#include <array>
#include <string>
using namespace std;

// constants
const size_t topicCount{5};
const size_t maxRating{10};
const array<string, topicCount>  topics{ 
   "global warming", "the economy", "war", "health care", "education"};

void pollUser(array<array<int, maxRating>, topicCount>&); // function prototype
void displayResults(array<array<int, maxRating>, topicCount>&); // function prototype
double calculateAverage(array<int, maxRating>&); // function prototype
void displayHighest(array<array<int, maxRating>, topicCount>&); // function prototype
void displayLowest(array<array<int, maxRating>, topicCount>&); // function prototype
int countPoints(array<int, maxRating>&); // function prototype

int main() {
   // empty initialization list initializes array to zero
   array<array<int, maxRating>, topicCount> responses{};
   int choice{1}; // sentinel to decide when to exit loop
   
   while (choice != 0) {
      cout <<endl; // add extra blank line
      pollUser(responses);

      // see if we should stop getting user input
      cout <<"Enter more data? (1=yes, 0=no): ";
      cin>> choice;
   } 

   displayResults(responses);
} 

// get ratings on topics from one user
void pollUser(array<array<int, maxRating>, topicCount>& responses) {
   for (size_t i{0}; i <responses.size(); ++i) {
      cout << "On a scale of 1-" << maxRating << ", how important is "
         << topics[i] << "?\n"; // ask question
      int rating; // rating user gave for this

      do {
         cout <<"> "; // display prompt
         cin>> rating; // read rating
      } while (rating <1 || rating> maxRating);

      ++responses[i][rating - 1]; // store rating
   } 
} 

// display polling results in tabular format
void displayResults(array<array<int, maxRating>, topicCount>& responses) {
   // display table header
   cout <<"\n" <<setw(15) <<left <<"Topic";

   for (int i{1}; i <= maxRating; ++i) {
      cout <<setw(4) << i;
   }

   cout <<setw(10) <<"Average" <<endl;

   // display rating counts and averages for each topic
   for (size_t i{0}; i < responses.size(); ++i) {
      cout << setw(15) << left << topics[i]; // display topic

      // display number of times topic was given this score
      for (size_t j{0}; j <responses[i].size(); ++j)
         cout << setw(4) << responses[i][j];

      // display average rating for this topic
      cout <<setprecision(1) << fixed << setw(10)
         <<calculateAverage(responses[i]) <<endl;
   } 

   cout <<endl; // add blank line
   displayHighest(responses); // display highest-rated issue
   displayLowest(responses); // display lowest-rated issue
} 

// calculate average number of points
double calculateAverage(array<int, maxRating>& votes) {
   int count{0}; // total number of votes

   for (size_t i{0}; i <votes.size(); ++i) {
      count += votes[i]; // add number of responses
   }

   return (double) countPoints(votes) / count; // return average
} 

// display topic with most points
void displayHighest(array<array<int, maxRating>, topicCount>& responses) {
   int max{countPoints(responses[0])}; // maximum number of points
   int maxIndex{0}; // index of issue with maximum number of points
   
   for (size_t i{1}; i <responses.size(); ++i) {
      if (countPoints(responses[i])> max) {
         // larger point count found, update maximum value and index
         max = countPoints(responses[i]);
         maxIndex = i;
      } 
   } 

   cout << "Highest points: " << topics[maxIndex] << " (" << max << ")\n";
} 

// display topic with fewest points
void displayLowest(array<array<int, maxRating>, topicCount>& responses) {
   int min{countPoints(responses[0])}; // minimum number of points
   int minIndex{0}; // index of issue with minimum number of points
   
   for (size_t i{1}; i <responses.size(); ++i) {
      if (countPoints(responses[i]) <min) {
         // smaller point count found, update minimum value and index
         min = countPoints(responses[i]);
         minIndex = i;
      } 
   } 

   cout << "Lowest points: " << topics[minIndex] << " (" << min << ")\n";
} 

// calculate total number of points for a given topic
int countPoints(array<int, maxRating>& votes) {
   int sum{0}; // total number of votes

   for (size_t i{0}; i < votes.size(); ++i) {
      sum += votes[i] * (i + 1); // add weighted count
   }

   return sum;
} 


/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
