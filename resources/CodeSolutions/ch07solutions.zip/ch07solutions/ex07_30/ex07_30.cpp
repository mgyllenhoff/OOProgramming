// Exercise 7.30 Solution: Ex07_30.cpp
#include <iostream> 
#include <iomanip> 
#include <random>
#include <array>
#include <ctime>
using namespace std;

const int SIZE{10};
const unsigned int MAXNUMBER{500};

void printArray(array< int, SIZE>&, size_t, size_t);

int main() {
   default_random_engine engine{static_cast<unsigned int>(time(0))};
   uniform_int_distribution<unsigned int> randomInt{1, MAXNUMBER};

   array<int, SIZE> values;

   // initialize array elements to random numbers
   for (auto &element : values) {
      element = randomInt(engine);
   }

   cout << "Array values printed in main:\n"; 

   for (auto element : values) { // print array elements
      cout << setw(5) << element;
   }

   cout << "\n\nArray values printed in printArray:\n";
   printArray(values, 0, SIZE - 1);
   cout << endl;
} 

void printArray(array<int, SIZE> &values, size_t low, size_t high) {
   // print first element of array passed
   cout << setw(5) << values[low];

   // return if array only has 1 element
   if (low == high) {
      return;
   }
   else { // recursively call printArray with new subarray as argument
      printArray(values, low + 1, high);
   }
}

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
