// Exercise 7.25 Part A Solution: Ex07_25.cpp
#include <iostream> 
#include <iomanip> 
#include <array>
#include <random>
#include <ctime>
using namespace std;

const size_t SIZE{8};

bool queenCheck(const array<array<char, SIZE>, SIZE>&, size_t, size_t);
void placeQueens(array<array<char, SIZE>, SIZE>&);
void printBoard(const array<array<char, SIZE>, SIZE>&);
void xConflictSquares(array<array<char, SIZE>, SIZE>&, size_t, size_t);
void xDiagonals(array<array<char, SIZE>, SIZE>&, size_t, size_t);
bool availableSquare(const array<array<char, SIZE>, SIZE>&);

inline int validMove(const array<array<char, SIZE>, SIZE>& board, size_t row, size_t col) { 
   return (row>= 0 && row <8 && col>= 0 && col <8);
} 

int main() {
   array<array<char, SIZE>, SIZE> board{'\0'};

   placeQueens(board); // try to place queens on board
   printBoard(board); // print board
} 

// function to determine if there are available squares
bool availableSquare(const array<array<char, SIZE>, SIZE>& board) {
   // test if squares are open
   for (size_t row{0}; row < SIZE; ++row) {
      for (size_t col{0}; col < SIZE; ++col) {
         if (board[row][col] == '\0') {
            return false; // at least one open square is available
         }
      }
   } 

   return true; // no available squares
} 

// function to try to put queens on board
void placeQueens(array<array<char, SIZE>, SIZE>& board) {
   default_random_engine engine{static_cast<unsigned int>(time(0))};
   uniform_int_distribution<unsigned int> randomInt{0, 7};

   const char QUEEN{'Q'};
   unsigned int queens{0};
   bool done{false};

   while (queens < SIZE && !done) {
      size_t rowMove{randomInt(engine)};
      size_t colMove{randomInt(engine)};

      // test if queen can be placed on board
      if (queenCheck(board, rowMove, colMove)) {
         board[rowMove][colMove] = QUEEN;
         xConflictSquares(board, rowMove, colMove);
         ++queens;
      } 

      // determine if there are available squares
      done = availableSquare(board);
   } 
} 

// function to mark occupied rows, columns and diagonals
void xConflictSquares(array<array<char, SIZE>, SIZE>& board, size_t row, size_t col) {
   // loop through board    
   for (size_t loop{0}; loop < SIZE; ++loop) {
      // place an '*' in the row occupied by the queen
      if (board[row][loop] == '\0') {
         board[row][loop] = '*';
      }

      // place an '*' in the col occupied by the queen
      if (board[loop][col] == '\0') {
         board[loop][col] = '*';
      }
   } 

   // place an '*' in the diagonals occupied by the queen
   xDiagonals(board, row, col);
} 

// function to determine if row, column, diagonal is occupied
bool queenCheck(const array<array<char, SIZE>, SIZE>& board, size_t row, size_t col) {
   size_t r{row};
   size_t c{col};

   // check row and column for a queen
   for (size_t d{0}; d < SIZE; ++d) {
      if (board[row][d] == 'Q' || board[d][col] == 'Q') {
         return false;
      }
   } 

   // check upper left diagonal for a queen
   for (size_t e{0}; e < SIZE && validMove(board, --r, --c); ++e) {
      if (board[r][c] == 'Q') {
         return false;
      }
   } 

   r = row;
   c = col;

   // check upper right diagonal for a queen
   for (size_t f{0}; f < SIZE && validMove(board, --r, ++c); ++f) {
      if (board[r][c] == 'Q') {
         return false;
      }
   } 

   r = row;
   c = col;

   // check lower left diagonal for a queen
   for (size_t g{0}; g < SIZE && validMove(board, ++r, --c); ++g) {
      if (board[r][c] == 'Q') {
         return false;
      }
   } 

   r = row;
   c = col;

   // check lower right diagonal for a queen
   for (size_t h{0}; h < SIZE && validMove(board, ++r, ++c); ++h) {
      if (board[r][c] == 'Q') {
         return false;
      }
   } 

   return true; // no queen in conflict
} 

void xDiagonals(array<array<char, SIZE>, SIZE>& board, size_t row, size_t col) {
   size_t r{row};
   size_t c{col};

   // upper left diagonal
   for (size_t a{0}; a < SIZE && validMove(board, --r, --c); ++a) {
      board[r][c] = '*';
   }

   r = row;
   c = col;

   // upper right diagonal
   for (size_t b{0}; b < SIZE && validMove(board, --r, ++c); ++b) {
      board[r][c] = '*';
   }

   r = row;
   c = col;

   // lower left diagonal
   for (size_t d{0}; d < SIZE && validMove(board, ++r, --c); ++d) {
      board[r][c] = '*';
   }

   r = row;
   c = col;

   // lower right diagonal
   for (size_t e{0}; e < SIZE && validMove(board, ++r, ++c); ++e) {
      board[r][c] = '*';
   }
} 

// function to print chess board
void printBoard(const array<array<char, SIZE>, SIZE>& board) {
   unsigned int queens{0};

   cout <<"   0 1 2 3 4 5 6 7\n"; // header for columns

   // print squares of board
   for (size_t r{0}; r <8; ++r) {
      cout <<setw(2) <<r <<' ';

      for (size_t c{0}; c <8; ++c) {
         cout <<board[r][c] <<' ';

         if (board[r][c] == 'Q') {
            ++queens;
         }
      } 

      cout <<'\n';
   } 

   // print how many queens were placed on board
   if (queens == SIZE) {
      cout <<"\nEight Queens were placed on the board!" <<endl;
   }
   else {
      cout <<'\n' <<queens <<" Queens were placed on the board.\n";
   }
}

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
