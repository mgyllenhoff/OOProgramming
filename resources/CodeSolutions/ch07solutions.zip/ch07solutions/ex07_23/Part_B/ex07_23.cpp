// Exercise 7.23 Part B Solution: Ex07_23.cpp
#include <iostream> 
#include <iomanip> 
#include <array>
#include <random>
#include <ctime>
using namespace std;

const size_t SIZE{8};
const int TOURS{1000};
const int MAXMOVES{65};

bool validMove(size_t, size_t, const array<array<int, SIZE>, SIZE>&);

int main() {
   default_random_engine engine{static_cast<unsigned int>(time(0))};
   uniform_int_distribution<unsigned int> randomInt{0, 7}; 

   array<int, MAXMOVES> moveTotal{0};
   array<array<int, SIZE>, SIZE> board{0};
   array<int, SIZE> horizontal{2, 1, -1, -2, -2, -1, 1, 2};
   array<int, SIZE> vertical{-1, -2, -2, -1, 1, 2, 2, 1};

   // set all squares equal to 0
   for (size_t i{0}; i < TOURS; ++i) {
      for (size_t row{0}; row < SIZE; ++row) {
         for (unsigned int col{0}; col < SIZE; ++col) {
            board[row][col] = 0;
         }
      } 
      
      unsigned int moveNumber{1};
      size_t currentRow{randomInt(engine)};
      size_t currentColumn{randomInt(engine)};
      board[currentRow][currentColumn] = moveNumber++;
      bool done{false};
   
      // continue while knight still has valid moves
      while (!done) {
         size_t moveType{randomInt(engine)};
         size_t testRow{currentRow + vertical[moveType]};
         size_t testColumn{currentColumn + horizontal[moveType]};
         bool goodMove{validMove(testRow, testColumn, board)};
      
         // if desired move is valid, move knight to square
         if (goodMove) {
            currentRow = testRow;
            currentColumn = testColumn;
            board[currentRow][currentColumn] = moveNumber++;
         } 
         else {
            // if move is invalid, test other possible moves
            for (int count{0}; count < SIZE - 1 && !goodMove; ++count) {
               moveType = ++moveType % SIZE;
               testRow = currentRow + vertical[moveType];
               testColumn = currentColumn + horizontal[moveType];
               goodMove = validMove(testRow, testColumn, board);

               // if move is valid, move knight to square
               if (goodMove) {
                  currentRow = testRow;
                  currentColumn = testColumn;
                  board[currentRow][currentColumn] = moveNumber++;
               } 
            } 

            // if no valid moves, while loop exits
            if (!goodMove) {
               done = true;
            }
         } 
      
         // if full tour is made, while loop exits
         if (moveNumber - 1 == 64) {
            done = true;
         }
      } 
      
      ++moveTotal[moveNumber];
   } 

   // display how many tours of each move number were made
   for (size_t j{1}; j < MAXMOVES; ++j) {
      if (moveTotal[j]) {
         cout << "There were " << moveTotal[j] << " tours of " << j
            << " moves." << endl;
      }
   } 
} 

// function to determine if a move is legal
bool validMove(size_t row, size_t column, 
   const array<array<int, SIZE>, SIZE>& workBoard) {
   // NOTE: This test stops as soon as it becomes false
   return (row >= 0 && row < SIZE && column >= 0 && column < SIZE
           && workBoard[row][column] == 0);
} 

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
