// Exercise 7.22 Part B Solution: Ex07_22.cpp
// Knight's Tour - access version
// runs one tour
#include <iostream> 
#include <iomanip>
#include <array>
#include <random>
#include <ctime>
using namespace std;

const size_t SIZE{8};

void printBoard(const array<array<int, SIZE>, SIZE>&);
bool validMove(size_t, size_t, const array<array<int, SIZE>, SIZE>&);

int main() {
   default_random_engine engine{static_cast<unsigned int>(time(0))};
   uniform_int_distribution<unsigned int> randomInt{0, 7};

   array<array<int, SIZE>, SIZE> board{0};
   array<int, SIZE> horizontal{2, 1, -1, -2, -2, -1, 1, 2};
   array<int, SIZE> vertical{-1, -2, -2, -1, 1, 2, 2, 1};

   unsigned int moveNumber{1};
   size_t currentRow{randomInt(engine)};
   size_t currentColumn{randomInt(engine)};
   board[currentRow][currentColumn] = moveNumber++;
   bool done{false};

   // continue until knight can no longer move
   while (!done) {
      size_t moveType{0};
      size_t testRow{currentRow + vertical[moveType]};
      size_t testColumn{currentColumn + horizontal[moveType]};
      bool goodMove{validMove(testRow, testColumn, board)};
      
      // test if desired move is valid
      if (goodMove) {
         currentRow = testRow;
         currentColumn = testColumn;
         board[currentRow][currentColumn] = moveNumber++;
      } 
      else {
         // if move is not legal, try another move
         for (unsigned int count{0}; count < SIZE - 1 && !goodMove; ++count) {
            moveType = ++moveType % SIZE;
            testRow = currentRow + vertical[moveType];
            testColumn = currentColumn + horizontal[moveType];
            goodMove = validMove(testRow, testColumn, board);

            // test if new move is valid
            if (goodMove) {
               currentRow = testRow;
               currentColumn = testColumn;
               board[currentRow][currentColumn] = moveNumber++;
            } 
         } 

         // if no valid moves, knight can no longer move
         if (!goodMove) {
            done = true;
         }
      } 

      // if 64 moves have been made, a full tour is complete
      if (moveNumber - 1 == 64) {
         done = true;
      }
   } 

   cout << "The tour ended with " << moveNumber - 1 << " moves.\n";
   
   // test and display whether full tour was made
   if (moveNumber - 1 == 64) {
      cout << "This was a full tour!\n\n";
   }
   else {
      cout << "This was not a full tour.\n\n";
   }

   cout << "The board for this test is:\n\n";
   printBoard(board);
} 

// function to print chess board
void printBoard(const array<array<int, SIZE>, SIZE>& workBoard) {
   // display the headings and squares
   cout << "   0  1  2  3  4  5  6  7\n";

   for (size_t row{0}; row < SIZE; ++row) {
      cout << row;

      for (size_t col{0}; col < SIZE; ++col) {
         cout << setw(3) << workBoard[row][col];
      }

      cout << '\n';
   } 

   cout << endl;
} 

// function to determine if move is legal
bool validMove(size_t row, size_t column, const array<array<int, SIZE>, SIZE>& workBoard) {
   // NOTE: This test stops as soon as it becomes false
   return (row >= 0 && row < SIZE && column >= 0 && column < SIZE
           && workBoard[row][column] == 0);
} 

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
