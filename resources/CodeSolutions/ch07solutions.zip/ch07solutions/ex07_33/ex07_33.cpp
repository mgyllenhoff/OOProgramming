// Exercise 7.33 Solution: Ex07_33.cpp
// This solution assumes that there is only one
// entrance and one exit for a given maze, and
// these are the only two dots on the borders.
#include <iostream> 
#include <array>
using namespace std;

enum class Direction {DOWN, RIGHT, UP, LEFT};
const size_t SIZE{12};

// function prototypes
void mazeTraversal(array<array<char, 12>, 12>&, size_t, size_t, size_t, size_t, Direction);
void printMaze(const array<array<char, 12>, 12>&);
bool validMove(const array<array<char, 12>, 12>&, size_t, size_t);
bool coordsAreEdge(size_t, size_t);

int main()
{
   array<array<char, 12>, 12> maze {
      '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#',
      '#', '.', '.', '.', '#', '.', '.', '.', '.', '.', '.', '#',
      '.', '.', '#', '.', '#', '.', '#', '#', '#', '#', '.', '#',
      '#', '#', '#', '.', '#', '.', '.', '.', '.', '#', '.', '#',
      '#', '.', '.', '.', '.', '#', '#', '#', '.', '#', '.', '.',
      '#', '#', '#', '#', '.', '#', '.', '#', '.', '#', '.', '#',
      '#', '.', '.', '#', '.', '#', '.', '#', '.', '#', '.', '#',
      '#', '#', '.', '#', '.', '#', '.', '#', '.', '#', '.', '#',
      '#', '.', '.', '.', '.', '.', '.', '.', '.', '#', '.', '#',
      '#', '#', '#', '#', '#', '#', '.', '#', '#', '#', '.', '#',
      '#', '.', '.', '.', '.', '.', '.', '#', '.', '.', '.', '#',
      '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'};

   size_t xStart{2}; // starting X and Y coordinates for maze
   size_t yStart{0};
   size_t x{xStart}; // current X and Y coordinates
   size_t y{yStart};

   mazeTraversal(maze, xStart, yStart, x, y, Direction::RIGHT);
} 

// Assume that there is exactly 1 entrance and exactly 1 exit to the maze.
void mazeTraversal(array<array<char, 12>, 12>& maze, size_t xStart, size_t yStart,
   size_t xCoord, size_t yCoord, Direction direction)
{
   static bool flag{false};

   maze[xCoord][yCoord] = 'x';
   printMaze(maze);

   if (coordsAreEdge(xCoord, yCoord) && xCoord != xStart && yCoord != yStart) {
      cout << "\nMaze successfully exited!\n\n";
      return; // maze is complete
   } 
   else if (xCoord == xStart && yCoord == yStart && flag) {
      cout << "\nArrived back at the starting location.\n\n";
      return;
   } 
   else {
      flag = true;

      Direction move = direction;

      // for loop uses switch to determine appropriate move   
      for (int count = 0; count < 4; ++count) {
         switch(move) 
         {
            case Direction::DOWN: // move down
               if (validMove(maze, xCoord + 1, yCoord)) 
               {
                  mazeTraversal(
                     maze, xStart, yStart, xCoord + 1, yCoord, Direction::LEFT);
                  return;
               } 
               break;
            case Direction::RIGHT: // move right
               if (validMove(maze, xCoord, yCoord + 1)) 
               {
                  mazeTraversal(
                     maze, xStart, yStart, xCoord, yCoord + 1, Direction::DOWN);
                  return;
               } 
               break;
            case Direction::UP: // move up
               if (validMove(maze, xCoord - 1, yCoord))  
               {
                  mazeTraversal(
                     maze, xStart, yStart, xCoord - 1, yCoord, Direction::RIGHT);
                  return;
               } 
               break;
            case Direction::LEFT: // move left
               if (validMove(maze, xCoord, yCoord - 1))  
               {
                  mazeTraversal(
                     maze, xStart, yStart, xCoord, yCoord - 1, Direction::UP);
                  return;
               } 
               break;
         } 

         // next direction
         move = static_cast<Direction>((static_cast<int>(move) + 1) % 4);
      }
   } 
} 

// validate move
bool validMove(const array<array<char, 12>, 12>& maze, size_t r, size_t c) {
   return (r >= 0 && r <= 11 && c >= 0 && c <= 11 && maze[r][c] != '#');
} 

// function to check coordinates
bool coordsAreEdge(size_t x, size_t y) {
   if ((x == 0 || x == SIZE - 1) && (y >= 0 && y <= SIZE - 1)) {
      return true;
   }
   else if ((y == 0 || y == SIZE - 1) && (x >= 0 && x <= SIZE - 1)) {
      return true;
   }
   else {
      return false;
   }
}

// print the current state of the maze
void printMaze(const array<array<char, 12>, 12>& maze) {
   // nested for loops to iterate through maze
   for (size_t x{0}; x < maze.size(); ++x) {
      for (size_t y{0}; y < maze[x].size(); ++y) {
         cout << maze[x][y] << ' ';
      }

      cout << '\n';
   } 

   cout << "\nHit return to see next move\n";
   cin.get();
} 

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
