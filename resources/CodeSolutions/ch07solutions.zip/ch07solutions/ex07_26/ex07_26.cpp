// Exercise 7.26 Solution: Ex07_26.cpp
#include <iostream> 
#include <iomanip> 
#include <array>
#include <random>
#include <ctime>
using namespace std;

const size_t SIZE{8}; // constant global variable

void printBoard(const array<array<int, SIZE>, SIZE>&);
bool validMove(size_t, size_t, const array<array<int, SIZE>, SIZE>&);

int main() {
   default_random_engine engine{static_cast<unsigned int>(time(0))};
   uniform_int_distribution<unsigned int> randomInt{0, 7};

   array<array<int, SIZE>, SIZE> board{0};
   array<int, SIZE> horizontal{2, 1, -1, -2, -2, -1, 1, 2};
   array<int, SIZE> vertical{-1, -2, -2, -1, 1, 2, 2, 1};
   array<array<int, SIZE>, SIZE> access{
      2, 3, 4, 4, 4, 4, 3, 2,
      3, 4, 6, 6, 6, 6, 4, 3,
      4, 6, 8, 8, 8, 8, 6, 4,
      4, 6, 8, 8, 8, 8, 6, 4,
      4, 6, 8, 8, 8, 8, 6, 4,
      4, 6, 8, 8, 8, 8, 6, 4,
      3, 4, 6, 6, 6, 6, 4, 3,
      2, 3, 4, 4, 4, 4, 3, 2};

   size_t minRow{0};
   size_t minColumn{0};
   int minAccess{9};
   int accessNumber{0};

   size_t currentRow{randomInt(engine)};
   size_t currentColumn{randomInt(engine)};
   size_t firstMoveRow{currentRow}; // store first moves row
   size_t firstMoveCol{currentColumn}; // store first moves col
   unsigned int moveNumber{1};

   board[currentRow][currentColumn] = moveNumber++;
   bool done{false};
   bool closedTour{false};

   // loop until knight cannot move anymore
   while (!done) {
      accessNumber = minAccess;

      // test what moves knight can make
      for (size_t moveType{0}; moveType < SIZE; moveType++) {
         size_t testRow{currentRow + vertical[moveType]};
         size_t testColumn{currentColumn + horizontal[moveType]};

         // if the knight can make a valid move, and that move has the
         // lowest accessNumber, move to that space
         if (validMove(testRow, testColumn, board)) {
            if (access[testRow][testColumn] <accessNumber) {
               accessNumber = access[testRow][testColumn];
               minRow = testRow;
               minColumn = testColumn;
            } 

            --access[testRow][testColumn];
         } 
      } 

      // if knight cannot access any more squares, while loop terminates
      if (accessNumber == minAccess) {
         done = true;
      }
      else {
         currentRow = minRow;
         currentColumn = minColumn;
         board[currentRow][currentColumn] = moveNumber++;

         // check for closed tour
         if (65 == moveNumber) {
            for (int m{0}; m < SIZE && closedTour == false; ++m) {
               size_t testRow{currentRow + vertical[m]};
               size_t testColumn{currentColumn + horizontal[m]};

               if (testRow == firstMoveRow && testColumn == firstMoveCol) {
                  closedTour = true;
               }
            } 
         } 
      } 
   } 

   // display results of tour
   cout <<"The tour ended with " <<moveNumber - 1 <<" moves.\n";

   if (moveNumber - 1 == 64 && closedTour == true) {
      cout <<"This was a CLOSED tour!\n\n";
   }
   else if (moveNumber - 1 == 64) {
      cout <<"This was a full tour!\n\n";
   }
   else {
      cout <<"This was not a full tour.\n\n";
   }

   cout <<"The board for this test is:\n\n";
   printBoard(board);
} 

// function to print chess board
void printBoard(const array<array<int, SIZE>, SIZE>& workBoard)
{
   // display the headings and squares
   cout <<"   0  1  2  3  4  5  6  7\n";

   for (size_t row{0}; row < SIZE; ++row) {
      cout <<row;

      for (size_t col{0}; col < SIZE; ++col) {
         cout <<setw(3) <<workBoard[row][col];
      }

      cout <<'\n';
   } 

   cout <<endl;
} 

// function to determine if move is legal
bool validMove(size_t row, size_t column, 
   const array<array<int, SIZE>, SIZE>& workBoard) {
   // NOTE: This test stops as soon as it becomes false
   return (row>= 0 && row < SIZE && column>= 0 && column < SIZE
           && workBoard[row][column] == 0);
} 

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
