// Exercise 4.35 Part A Solution: ex04_35.cpp
// Compute and print the factorial of the specified value.
#include <iostream>
using namespace std; 

int main() {
   int number; // user input
   unsigned int factorial{1}; // factorial of input value

   // get input
   cout << "Enter a positive Integer: ";
   cin >> number;
      
   cout << number << "! is ";
   
   while (number > 0) { // calculate factorial
      factorial *= number;
      --number;
   } 

   cout << factorial << endl;
} 


/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
