// Exercise 11.3 Solution: BasePlusCommissionEmployee.cpp
// Member-function definitions of class BasePlusCommissionEmployee 
// using composition.
#include <iostream>
#include <sstream>
#include <stdexcept>

// BasePlusCommissionEmployee class definition
#include "BasePlusCommissionEmployee.h"
using namespace std;

// constructor
BasePlusCommissionEmployee::BasePlusCommissionEmployee(
   const string& first, const string& last, const string& ssn, 
   double sales, double rate, double salary) 
   // initialize composed object
   : commissionEmployee(first, last, ssn, sales, rate) {
   setBaseSalary(salary); // validate and store base salary
} 

// set commission employee's first name
void BasePlusCommissionEmployee::setFirstName(const string& first) {
   commissionEmployee.setFirstName(first);
} 

// return commission employee's first name
string BasePlusCommissionEmployee::getFirstName() const {
   return commissionEmployee.getFirstName();
} 

// set commission employee's last name
void BasePlusCommissionEmployee::setLastName(const string& last) {
   commissionEmployee.setLastName(last);
} 

// return commission employee's last name
string BasePlusCommissionEmployee::getLastName() const {
   return commissionEmployee.getLastName();
} 

// set commission employee's social security number
void BasePlusCommissionEmployee::setSocialSecurityNumber(const string& ssn) {
   commissionEmployee.setSocialSecurityNumber(ssn);
} 

// return commission employee's social security number
string BasePlusCommissionEmployee::getSocialSecurityNumber() const {
   return commissionEmployee.getSocialSecurityNumber();
} 

// set commission employee's gross sales amount
void BasePlusCommissionEmployee::setGrossSales(double sales) {
   commissionEmployee.setGrossSales(sales);
} 

// return commission employee's gross sales amount
double BasePlusCommissionEmployee::getGrossSales() const {
   return commissionEmployee.getGrossSales();
} 

// set commission employee's commission rate
void BasePlusCommissionEmployee::setCommissionRate(double rate) {
   commissionEmployee.setCommissionRate(rate);
} 

// return commission employee's commission rate
double BasePlusCommissionEmployee::getCommissionRate() const {
   return commissionEmployee.getCommissionRate();
} 

// set base salary
void BasePlusCommissionEmployee::setBaseSalary(double salary) {
   if (salary >= 0.0) {
      baseSalary = salary;
   }
   else {
      throw invalid_argument("Salary must be >= 0.0");
   }
}

// return base salary
double BasePlusCommissionEmployee::getBaseSalary() const {
   return baseSalary;
} 

// calculate earnings
double BasePlusCommissionEmployee::earnings() const {
   return getBaseSalary() + commissionEmployee.earnings();
} 

// print BasePlusCommissionEmployee object
string BasePlusCommissionEmployee::toString() const {
   ostringstream output;
   output << "base-salaried " << commissionEmployee.toString()
      << "\nbase salary: " << getBaseSalary();
   return output.str();
}



/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
