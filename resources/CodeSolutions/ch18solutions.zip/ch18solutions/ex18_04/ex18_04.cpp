// Exercise 18.4 Solution: Ex18_04.cpp
#include <iostream>
#include <string>
#include "Array.h"
using namespace std;

int main() {
   Array<int> intArray{5}; // create intArray object

   // initialize intArray with user input values
   cout << "Enter " << intArray.getSize() << " integer values:\n";
   for (size_t i{0}; i < intArray.getSize(); ++i) {
      cin >> intArray[i];
   }

   // output intArray
   cout << "\nThe values in intArray are:\n";
   for (size_t i{0}; i < intArray.getSize(); ++i) {
      cout << intArray[i] << " ";
   }
   cout << endl;

   Array<string> stringArray{3}; // create stringArray

   // initialize stringArray with user input values
   cout << "\nEnter " << stringArray.getSize()
      << " one-word string values:\n";
   for (size_t i{0}; i < stringArray.getSize(); ++i) {
      cin >> stringArray[i];
   }

   // output stringArray
   cout << "\nThe values in the stringArray are:\n";
   for (size_t i{0}; i < stringArray.getSize(); ++i) {
      cout << stringArray[i] << " ";
   }
   cout << endl;
} 

/**************************************************************************
 * (C) Copyright 1992-2010 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
