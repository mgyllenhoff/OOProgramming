// Exercise 5.15 Solution: ex05_15.cpp
// Create triangles of asterisks using nested for loops.
#include <iostream>
using namespace std; 

int main() {
   // first triangle
   for (unsigned int row{1}; row <= 10; ++row) {
      for (unsigned int column{1}; column <= row; ++column) {
         cout << "*";
      }

      cout << endl;
   } 

   cout << endl;

   // second triangle
   for (unsigned int row{10}; row >= 1; --row) {
      for (unsigned int column{1}; column <= row; ++column) {
         cout << "*";
      }

      cout << endl;
   } 

   cout << endl;

   // third triangle
   for (unsigned int row{10}; row >= 1; --row) {
      for (unsigned int space{10}; space > row; --space) {
         cout << " ";
      }

      for (unsigned int column{1}; column <= row; ++column) {
         cout << "*";
      }

      cout << endl;
   } 

   cout << endl;

   // fourth triangle
   for (unsigned int row{10}; row >= 1; --row) {
      for (unsigned int space{1}; space < row; ++space) {
         cout << " ";
      }

      for (unsigned int column{10}; column >= row; --column) {
         cout << "*";
      }

      cout << endl;
   } 
} 

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
