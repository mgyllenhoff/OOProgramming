// Exercise 5.14 Solution: ex05_14.cpp
// Calculating compound interest with several interest rates.
#include <iostream> 
#include <iomanip> // parameterized stream manipulators
#include <cmath> // math functions
using namespace std;

int main() {
   // set floating-point number format
   cout << fixed << setprecision(2);

   double principal{1000.00}; // initial amount before interest

   // loop through interest rates 5% to 10%
   for (unsigned int rate = 5; rate <= 10; ++rate) {
      // display headers
      cout << "Interest Rate: " << rate << "%" 
         << "\nYear" << setw(20) << "Amount on deposit" << endl;

      // calculate amount on deposit for each of ten years
      for (unsigned int year{1}; year <= 10; ++year) {
         // calculate new amount for specified year
         double amount{principal * pow(1 + (rate / 100.0), year)};

         // display the year and the amount
         cout << setw(4) << year << setw(20) << amount << endl;
      }
   
      cout << '\n';
   } 

   cout << endl;
} 



/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
