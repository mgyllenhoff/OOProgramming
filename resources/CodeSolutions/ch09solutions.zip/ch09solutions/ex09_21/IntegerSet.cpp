// Exercise 9.21 Solution: IntegerSet.cpp
// Member-function definitions for class IntegerSet.
#include <iostream> 
#include <sstream>
#include "IntegerSet.h" // IntegerSet class definition
using namespace std;

// constructor creates a set from array of integers
IntegerSet::IntegerSet(int array[], int size) : set(setSize) {
   for (int i{0}; i < size; ++i) {
      insertElement(array[i]);
   }
} 

// input a set from the user
void IntegerSet::inputSet() {
   int number{0};

   do {
      cout << "Enter an element (-1 to end): ";
      cin >> number;

      if (validEntry(number)) {
         set[number] = true;
      }
      else if (number != -1) {
         cout << "Invalid Element\n";
      }
   } while (number != -1); 

   cout << "Entry complete\n";
} 

// prints the set to the output stream
string IntegerSet::toString() const {
   ostringstream output;
   int x{1};
   bool empty{true}; // assume set is empty
   
   output << "{ ";

   for (int i{0}; i < setSize; ++i) {
      if (set[i]) {
         output << i << " ";
         empty = false; // set is not empty
         ++x;
      } 
   } 

   if (empty) {
      output << "--- "; // display an empty set
   }

   output << "}";
   return output.str();
} 

// returns the union of two sets
IntegerSet IntegerSet::unionOfSets(const IntegerSet &r) const {
   IntegerSet temp;

   // if element is in either set, add to temporary set
   for (int i{0}; i < setSize; ++i) {
      temp.set[i] = set[i] || r.set[i];
   }

   return temp;
} 

// returns the intersection of two sets
IntegerSet IntegerSet::intersectionOfSets(const IntegerSet &r) const {
   IntegerSet temp;

   // if element is in both sets, add to temporary set
   for (int i{0}; i < setSize; ++i) {
      temp.set[i] = set[i] && r.set[i];
   }

   return temp;
} 

// insert a new integer into this set
void IntegerSet::insertElement(int k) {
   if (validEntry(k)) {
      set[k] = true;
   }
   else {
      cout << "Invalid insert attempted!\n";
   }
} 

// removes an integer from this set
void IntegerSet::deleteElement(int k) {
   if (validEntry(k)) {
      set[k] = false;
   }
   else {
      cout << "Invalid delete attempted!\n";
   }
} 

// determines if two sets are equal
bool IntegerSet::isEqualTo(const IntegerSet &r) const {
   for (int i{0}; i < setSize; ++i) {
      if (set[i] != r.set[i]) {
         return false; // sets are not equal
      }
   }

   return true; // sets are equal
} 


/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
