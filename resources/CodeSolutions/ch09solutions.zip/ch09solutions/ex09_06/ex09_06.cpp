// Exercise 9.6 Solution: Ex09_06.cpp
#include <iostream> 
#include "Rational.h" // include definition of class Rational
using namespace std;

int main() {
   Rational c{2, 6};
   Rational d{7, 8};

   Rational x = c.add(d); // adds object c and d; sets the value to x
   cout << c.toRationalString() << " + " << d.toRationalString() << " = " 
      << x.toRationalString() << '\n';
   cout << x.toRationalString() << " = " << x.toDouble() << "\n\n";

   x = c.subtract(d); // subtracts object c and d 
   cout << c.toRationalString() << " - " << d.toRationalString() << " = "
      << x.toRationalString() << '\n';
   cout << x.toRationalString() << " = " << x.toDouble() << "\n\n";

   x = c.multiply(d); // multiplies object c and d
   cout << c.toRationalString() << " + " << d.toRationalString() << " = "
      << x.toRationalString() << '\n';
   cout << x.toRationalString() << " = " << x.toDouble() << "\n\n";

   x = c.divide(d); // divides object c and d
   cout << c.toRationalString() << " + " << d.toRationalString() << " = "
      << x.toRationalString() << '\n';
   cout << x.toRationalString() << " = " << x.toDouble() << "\n";
}

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/


