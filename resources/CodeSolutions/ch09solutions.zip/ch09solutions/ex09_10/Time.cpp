// Exercise 9.10 Solution: Time.cpp
// Member-function definitions for class Time.
#include <iostream> 
#include <iomanip>
#include <sstream>
#include "Time.h" // include definition of class Time
using namespace std;

// Time constructor initializes each data member 
Time::Time(int hour, int minute, int second) { 
   setTime(hour, minute, second); // validate and set time
} 

bool Time::setTime(int h, int m, int s) {
   bool hourValid{setHour(h)}; // invokes function setHour           
   bool minuteValid{setMinute(m)}; // invokes function setMinute
   bool secondValid{setSecond(s)}; // invokes function setSecond
   return hourValid && minuteValid && secondValid;
} 

bool Time::setHour(int hr) {
   if (hr >= 0 && hr < 24) {
      hour = hr;
      return true; // hour is valid
   } 
   else {
      return false; // hour is invalid
   }
} 

bool Time::setMinute(int min) {
   if (min >= 0 && min < 60) {
      minute = min;
      return true; // minute is valid
   } 
   else {
      return false; // minute is invalid
   }
} 

bool Time::setSecond(int sec) {
   if (sec >= 0 && sec < 60) {
      second = sec;
      return true; // second is valid
   } 
   else {
      return false; // second is invalid
   }
} 

// return hour value
unsigned int Time::getHour() const {
   return hour;
} 

// return minute value
unsigned int Time::getMinute() const {
   return minute;
} 

// return second value
unsigned int Time::getSecond() const {
   return second;
} 

// return Time as a string in universal-time format (HH:MM:SS)
string Time::toUniversalString() const {
   ostringstream output;
   output << setfill('0') << setw(2) << getHour() << ":"
      << setw(2) << getMinute() << ":" << setw(2) << getSecond();
   return output.str();
}

// return Time as string in standard-time format (HH:MM:SS AM or PM)
string Time::toStandardString() const {
   ostringstream output;
   output << ((getHour() == 0 || getHour() == 12) ? 12 : getHour() % 12)
      << ":" << setfill('0') << setw(2) << getMinute() << ":" << setw(2)
      << getSecond() << (hour < 12 ? " AM" : " PM");
   return output.str();
}



/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/


