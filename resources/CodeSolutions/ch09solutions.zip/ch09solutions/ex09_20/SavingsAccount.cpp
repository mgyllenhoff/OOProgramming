// Exercise 9.20 Solution: SavingsAccount.cpp
// Member-function defintions for class SavingsAccount.
#include <iostream> 
#include <iomanip>
#include "SavingsAccount.h" // SavingsAccount class definition
using namespace std;

double SavingsAccount::annualInterestRate = 0.0; // the interest rate of all accounts

// calculate monthly interest for this savings account
void SavingsAccount::calculateMonthlyInterest() { 
   savingsBalance += savingsBalance * (annualInterestRate / 12.0); 
} 

// function for modifying static member variable annualInterestRate
void SavingsAccount::modifyInterestRate(double i) { 
   annualInterestRate = (i >= 0.0 && i <= 1.0) ? i : 0.03; 
} 

// prints balance of the savings account
void SavingsAccount::printBalance() const {
   cout << fixed << '$' << setprecision(2) << savingsBalance;
} 


/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
