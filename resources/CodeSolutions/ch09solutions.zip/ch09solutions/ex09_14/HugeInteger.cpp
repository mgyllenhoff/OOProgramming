// Exercise 9.14 Solution: HugeInteger.cpp
// Member-function definitions for class HugeInteger.
#include <iostream>
#include <sstream>
#include "HugeInteger.h" // include definition of class HugeInteger 
using namespace std;

// default constructor; conversion constructor that converts
// a long integer into a HugeInteger object
HugeInteger::HugeInteger(long value) {
   // initialize array to zero
   for (int i{0}; i < 40; ++i) {
      integer[i] = 0;   
   }

   // place digits of argument into array 
   for (int j{39}; value != 0 && j >= 0; --j) {
      integer[j] = static_cast< short >(value % 10);
      value /= 10;
   } 
} 

// copy constructor; 
// converts a char string representing a large integer into a HugeInteger
HugeInteger::HugeInteger(const string& string) {
   input(string); // call input to initialize HugeInteger
} 

// addition operator; HugeInteger + HugeInteger
HugeInteger HugeInteger::add(const HugeInteger& op2) const {
   HugeInteger temp; // temporary result
   int carry{0};

   // iterate through HugeInteger
   for (int i{39}; i >= 0; --i) {
      temp.integer[i] = integer[i] + op2.integer[i] + carry;

      // determine whether to carry a 1
      if (temp.integer[i] > 9) {
         temp.integer[i] %= 10; // reduce to 0-9
         carry = 1;
      } 
      else { // no carry
         carry = 0;
      }
   } 

   return temp; // return the sum
} 

// addition operator; HugeInteger + int
HugeInteger HugeInteger::add(int op2) const { 
   // convert op2 to a HugeInteger, then invoke add
   return add(HugeInteger(op2)); 
} 
 
// HugeInteger + string that represents large integer value
HugeInteger HugeInteger::add(const string& op2) const { 
   // convert op2 to a HugeInteger, then invoke add
   return add(HugeInteger(op2)); 
} 

// subtraction operator, subtract op2 from (*this)
HugeInteger HugeInteger::subtract(const HugeInteger& op2) const {
   // return if first value is smaller; we are not handling negatives
   if (isLessThan(op2)) {
      cout << "Error: Tried to subtract larger value from smaller value." << endl;
      return HugeInteger("0");
   } 

   HugeInteger result("0"); // final result currently 0

   // used to determine if previous digit had 10 added to it;
   // if true, current digit needs to be reduced by 1
   bool minusOne{false};

   // for each digit in both arrays,
   // subtract digit of smaller int from digit of larger int
   for (int i{39}; i >= 0; --i) {
      // find digits we will currently be subtracting
      int topValue{integer[i]};
      int bottomValue{op2.integer[i]};

      // if previous topValue had 10 added to it;
      // subtract one from current topValue
      if (minusOne) {
         if (topValue == 0) { // topValue cannot become -1
            // set to 9 but keep minusOne true for next digit
            topValue = 9; 
         }
         else {
            topValue -= 1; // subtract from top value
            minusOne = false; // minusOne is handled, return to false
         } 
      } 

      // if topValue larger, perform subtraction and store result
      if (topValue >= bottomValue) {
         result.integer[i] = topValue - bottomValue;
      }
      else {        
         topValue += 10; // if bottomValue larger, add 10 to topValue
         minusOne = true; // next digit must be decreased

         // topValue is now larger, perform subtraction and store result
         result.integer[i] = topValue - bottomValue;
      } 
   } 

   return result; // return final result
} 

// function to subtract an integer from a HugeInteger
HugeInteger HugeInteger::subtract(int op2) const { 
   // convert op2 to a HugeInteger, then invoke subtract
   return subtract(HugeInteger(op2)); 
} 

// function that takes string representing a number
// and subtracts it from a HugeInteger
HugeInteger HugeInteger::subtract(const string& op2) const { 
   // convert op2 to a HugeInteger, then invoke subtract
   return subtract(HugeInteger(op2)); 
} 

// function that tests if two HugeIntegers are equal
bool HugeInteger::isEqualTo(const HugeInteger& x) const {
   for (int i{39}; i >= 0; --i) { 
      if (integer[i] != x.integer[i]) {
         return false;
      }
   }

   return true;   
} 
 
// function that tests if two HugeIntegers are not equal
bool HugeInteger::isNotEqualTo(const HugeInteger& x) const {
   return !(isEqualTo(x)); 
} 

// function to test if one HugeInteger is greater than another
bool HugeInteger::isGreaterThan(const HugeInteger& x) const {  
   return (x.isLessThan(*this));
} 

// function that tests if one HugeInteger is less than another
bool HugeInteger::isLessThan(const HugeInteger& x) const {  
   for (int i{0}; i < 40; ++i) {
      if (integer[i] > x.integer[i]) {
         return false;
      }
      else if (integer[i] < x.integer[i]) {
         return true;
      }
   }

   return false;
} 

// function that tests if one HugeInteger is greater than
// or equal to another
bool HugeInteger::isGreaterThanOrEqualTo(const HugeInteger& x) const {
   return (!isLessThan(x));
} 

// function that tests if one HugeInteger is less than or
// equal to another
bool HugeInteger::isLessThanOrEqualTo(const HugeInteger& x) const {
   return (isEqualTo(x) || isLessThan(x));
} 

// function that tests if a HugeInteger is zero
bool HugeInteger::isZero() const {
   for (int i{0}; i < 40; ++i) {
      if (integer[i] != 0) {
         return false;
      }
   }
         
   return true;
} 

// converts a string representing a large integer into a HugeInteger
void HugeInteger::input(const string& val) {
   // initialize array to zero
   for (int i{0}; i < 40; ++i) {
      integer[i] = 0;
   }

   // place digits of argument into array
   unsigned int length{val.size()};

   for (unsigned int j{40 - length}, k{0}; j < 40; ++j, ++k) {
      if (isdigit(val[k])) {
         integer[j] = val[k] - '0'; 
      }
   }
} 

// overloaded output operator
string HugeInteger::toString() const {
   int i; // used for looping

   for (i = 0; (i < 40) && (integer[i] == 0); ++i) {
      ; // skip leading zeros
   }


   if (i == 40) {
      return "0";
   }
   else {
      ostringstream output;

      for (; i < 40; ++i) { // display the HugeInteger
         output << integer[i];
      }

      return output.str();
   }
} 

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/


