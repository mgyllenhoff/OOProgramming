// Exercise 9.9 Solution: DateAndTime.cpp
// Member function definitions for class DateAndTime.
#include <iomanip> 
#include <iostream> 
#include <sstream>
#include <stdexcept>
#include <array>
#include "DateAndTime.h" // include definition of class DateAndTime
using namespace std;

DateAndTime::DateAndTime(int m, int d, int y, int hr, int min, int sec) {
   setDate(m, d, y); // sets date
   setTime(hr, min, sec); // sets time
} 

void DateAndTime::setDate(int mo, int dy, int yr) {   
   setMonth(mo); // invokes function setMonth
   setDay(dy); // invokes function setday
   setYear(yr); // invokes function setYear 
} 

void DateAndTime::setDay(int d) {
   if (month == 2 && leapYear() && d <= 29 && d >= 1) {
      day = d;
   }
   else if (d <= monthDays() && d >= 1) {
      day = d;
   }
   else {
      throw invalid_argument("day out of range for current month");
   }
} 

void DateAndTime::setMonth(int m) { 
   if (m <= 12 && m >= 1) {
      month = m;
   }
   else {
      throw invalid_argument("month invalid");
   }
} 

void DateAndTime::setYear(int y) { 
   if (y >= 2000) {
      year = y; 
   }
   else {
      throw invalid_argument("year invalid");
   }
} 

void DateAndTime::nextDay() {
   try {
      setDay(getDay() + 1); // increments day by 1
   }
   catch (invalid_argument&) { 
      setDay(1);

      try {
         setMonth(getMonth() + 1);
      }
      catch (invalid_argument&) {
         setMonth(1);
         setYear(getYear() + 1);
      }
   }
}

void DateAndTime::setTime(int hr, int min, int sec) {
   setHour(hr); // invokes function setHour
   setMinute(min); // invokes function setMinute
   setSecond(sec); // invokes function setSecond
} 

void DateAndTime::setHour(int h) { 
   if (h >= 0 && h < 24) {
      hour = h;
   }
   else {
      throw invalid_argument("hour must be 0-23");
   }
} 

void DateAndTime::setMinute(int m) { 
   if (m >= 0 && m < 60) {
      minute = m; 
   }
   else {
      throw invalid_argument("minute must be 0-59");
   }
} 

void DateAndTime::setSecond(int s) { 
   if (s >= 0 && s < 60) {
      second = ((s >= 0 && s < 60) ? s : 0); 
   }
   else {
      throw invalid_argument("second must be 0-59");
   }
} 

void DateAndTime::tick() {
   unsigned int tempSecond{getSecond()};

   if (tempSecond < 59) {
      setSecond(tempSecond + 1); // increment second by 1
   }
   else {
      setSecond(0);
      unsigned int tempMinute{getMinute()};

      if (tempMinute < 59) {
         setMinute(tempMinute + 1);
      }
      else {
         setMinute(0);
         unsigned int tempHour{getHour()};

         if (tempHour < 23) {
            setHour(tempHour + 1);
         }
         else {
            setHour(0);
            nextDay();
         }
      } 
   } 
} 

unsigned int DateAndTime::getDay() const { 
   return day; 
} 

unsigned int DateAndTime::getMonth() const {
   return month; 
} 

unsigned int DateAndTime::getYear() const { 
   return year; 
} 

unsigned int DateAndTime::getHour() const { 
   return hour; 
} 

unsigned int DateAndTime::getMinute() const { 
   return minute; 
} 

unsigned int DateAndTime::getSecond() const { 
   return second; 
} 

string DateAndTime::toUniversalString() const {
   ostringstream output;
   output << setfill('0') << setw(2) << getHour() << ":"
      << setw(2) << getMinute() << ":" << setw(2) << getSecond() << " "
      << month << '-' << day << '-' << year;;
   return output.str();
}

string DateAndTime::toStandardString() const {
   ostringstream output;
   output << ((getHour() == 0 || getHour() == 12) ? 12 : getHour() % 12)
      << ":" << setfill('0') << setw(2) << getMinute() << ":" << setw(2)
      << getSecond() << (hour < 12 ? " AM" : " PM") << " " 
      << month << '-' << day << '-' << year;
   return output.str();
}

bool DateAndTime::leapYear() const {
   return (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)); 
} 

int DateAndTime::monthDays() const {
   const array<int, 12> days = { 
      31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

   return (month == 2 && leapYear()) ? 29 : days[(month - 1)];
} 


/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/


