// Exercise 9.8 Solution: Date.h
#ifndef DATE_H
#define DATE_H
#include <string>

class Date {
public:
   explicit Date(int = 1, int = 1, int = 2000); // default constructor
   std::string toString(); // convert to string format
   void setDate(int, int, int); // set month, day, year
   void setMonth(int); // set month
   void setDay(int); // set day
   void setYear(int); // set year
   unsigned int getMonth() const; // get month
   unsigned int getDay() const; // get day
   unsigned int getYear() const; // get year 
   void nextDay(); // next day
private:
   unsigned int month;
   unsigned int day;
   unsigned int year;
   bool leapYear() const; // leap year
   int monthDays() const; // days in month 			
}; 

#endif

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/


