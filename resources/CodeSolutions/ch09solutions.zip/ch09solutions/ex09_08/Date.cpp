// Exercise 9.8 Solution: Date.cpp
// Member-function definitions for class Date.
#include <iostream> 
#include <sstream>
#include <stdexcept>
#include <array>
#include "Date.h" // include definition of class Date
using namespace std;

Date::Date(int m, int d, int y) 
{
   setDate(m, d, y); // sets date 
} 

void Date::setDate(int mo, int dy, int yr)
{
   setMonth(mo); // invokes function setMonth 
   setDay(dy); // invokes function setDay	
   setYear(yr); // invokes function setYear
} 

void Date::setDay(int d)
{
   if (month == 2 && leapYear() && d <= 29 && d >= 1)  
      day = d; 
   else if (d <= monthDays() && d >= 1) 
      day = d;
   else 
      throw invalid_argument("day out of range for current month");
} 

void Date::setMonth(int m) 
{ 
   if (m <= 12 && m >= 1)
      month = m;
   else
      throw invalid_argument("month invalid");
} 

void Date::setYear(int y) 
{
   if (y >= 2000)
      year = y; 
   else
      throw invalid_argument("year invalid");
} 

unsigned int Date::getDay() const 
{
   return day;
} 

unsigned int Date::getMonth() const 
{ 
   return month; 
} 

unsigned int Date::getYear() const 
{ 
   return year; 
} 

string Date::toString()
{
   ostringstream output;
   output << month << '-' << day << '-' << year;
   return output.str();
} 

void Date::nextDay()
{
   try
   {
      setDay(getDay() + 1); // increments day by 1
   }
   catch (invalid_argument &)
   { 
      setDay(1);

      try 
      {
         setMonth(getMonth() + 1);
      }
      catch (invalid_argument &)
      {
         setMonth(1);
         setYear(getYear() + 1);
      }
   }
} 

bool Date::leapYear() const
{
   if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0))
         return true; // is a leap year
      else
         return false; // is not a leap year
} 

int Date::monthDays() const
{
   const array< int, 12 > days = { 
      31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

   return month == 2 && leapYear() ? 29 : days[month - 1];
} 

/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/


