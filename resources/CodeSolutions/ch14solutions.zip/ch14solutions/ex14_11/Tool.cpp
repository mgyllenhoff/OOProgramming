// Exercise 14.11 Solution: Tool.cpp
// Member function definitions for class Tool.
#include <string>
#include "Tool.h"
using namespace std;

// default Tool constructor
Tool::Tool(int partNumberValue, const string& toolNameValue, int inStockValue,
   double unitPriceValue) {
   setPartNumber(partNumberValue);
   setToolName(toolNameValue);
   setInStock(inStockValue);
   setUnitPrice(unitPriceValue);
} 

// set part-number value
void Tool::setPartNumber(int partNumberValue) {
   partNumber = partNumberValue;
} 

// get part-number value
int Tool::getPartNumber() const {
   return partNumber;
} 

// set tool-name value
void Tool::setToolName(const string& toolNameString) {
   // copy at most 29 characters from string to toolName
   size_t length{toolNameString.size()};
   length = (length < LENGTH ? length : LENGTH - 1);
   toolNameString.copy(toolName, length);

   // append null-terminating character to end of toolName
   toolName[length] = '\0';
} 

// get tool-name value
string Tool::getToolName() const {
   return toolName;
} 

// set in-stock value
void Tool::setInStock(int inStockValue) {
   inStock = inStockValue;
} 

// get in-stock value
int Tool::getInStock() const {
   return inStock;
} 

// set unit-price value
void Tool::setUnitPrice(double unitPriceValue) {
   unitPrice = unitPriceValue;
} 

// get unit-price value
double Tool::getUnitPrice() const {
   return unitPrice;
} 



/**************************************************************************
 * (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
